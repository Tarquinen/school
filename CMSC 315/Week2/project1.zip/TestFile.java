public class TestFile {
/* 
 * }
 * {{{{
*/


   public static void main(String[] args) { 
      System.out.println("Hello,( World!"); //]
      //test comment )))
      System.out.println(']');
      // System.out.println('a\'b');
      System.out.println('\'');
      System.out.println("test stuff \"");
      System.out.println("test more esc stuff \\");
   }
